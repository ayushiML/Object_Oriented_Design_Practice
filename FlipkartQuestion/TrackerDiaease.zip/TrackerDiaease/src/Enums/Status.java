package Enums;

public enum Status {
    ACTIVE,
    FATAL,
    CURED
}
