package Enums;

public enum TrendType
{
    DAILY,
    MONTHLY,
    HOURLY;
}