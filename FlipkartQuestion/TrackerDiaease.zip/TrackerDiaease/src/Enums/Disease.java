package Enums;

public enum Disease {
    COVID_19,SPANSIH_FLU;
}
