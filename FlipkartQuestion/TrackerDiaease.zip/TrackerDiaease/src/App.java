//import org.graalvm.compiler.core.common.alloc.Trace;

import Enums.Disease;
import Service.ReportService;
import Service.TrackerService;

public class App {
    public static void main(String[] args) throws Exception {
       TrackerService trackerService = new TrackerService();
       ReportService reportService = new ReportService();

       //add request
       trackerService.addReport(Disease.COVID_19, 1, "INDIA", "MP", "UJJAIN");
       trackerService.addReport(Disease.SPANSIH_FLU, 2, "INDIA","UP", "UJ");
       trackerService.addReport(Disease.COVID_19, 3, "INDIA", "MAHA", "UJJAIN");
       trackerService.addReport(Disease.COVID_19, 4, "INDIA", "MAHA", "UJJAIN");
       trackerService.addReport(Disease.COVID_19, 5, "INDIA", "MAHA", "UJJAIN");
       trackerService.addReport(Disease.COVID_19, 6, "INDIA", "MAHA", "UJJAIN");
       
       trackerService.updateCured(4, Disease.COVID_19);
       trackerService.updateFatal(5, Disease.COVID_19);
       reportService.showAllCases();
       reportService.ShowWorldSummary();
       reportService.ShowWorldSummaryDiseasesBreakup();
    }
}
