package Models;

public class Region {
    String country;
    String city;
    String state;

    public Region(String country,String state , String city){
        this.country = country;
        this.city = city;
        this.state = state;

       
    }
    //more constructor

}
