package Models;

public class Patient {
    int pid;
    String name;
    String age;
    String sex;
}
