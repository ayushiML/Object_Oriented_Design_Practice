package Models;

public class Time {
    public String max;
    public String min;
    public String avgTime;

    public Time(String max, String min, String avgTime) {
        this.max = max;
        this.min = min;
        this.avgTime = avgTime;
    }

   

}
